"use client";

import { useEffect, useState } from "react";
import styles from "./Header.module.css";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`${styles.header} ${
        scrolled ? styles.scrolled : ""
      }`}
    >
      <div className="mx-auto max-w-7xl px-6 flex items-center justify-between h-20">
        {/* LOGO */}
        <div className="font-anton text-xl tracking-wide">
          KERNING
        </div>

        {/* DESKTOP ACTIONS */}
        <div className="hidden md:flex items-center gap-6">
          <button className="font-anton tracking-wide">
            Menu
          </button>

          <button className="rounded-full border border-white/20 px-5 py-2 text-sm hover:bg-white hover:text-black transition">
            Contattaci
          </button>
        </div>

        {/* MOBILE MENU */}
        <button className="md:hidden font-anton">
          Menu
        </button>
      </div>
    </header>
  );
}
