export default function Page() {
  return (
    <div style={{ padding: 32 }}>
      <h1>QUESTO È ANTON</h1>
      <p>Questo è Inter.</p>
    </div>
  );
}
